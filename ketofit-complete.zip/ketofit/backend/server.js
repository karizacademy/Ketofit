/**
 * KetóFit Backend Server
 * Node.js + Express
 * 
 * Features:
 *  - Storage API (replaces window.storage)
 *  - Anthropic API proxy (keeps API key server-side)
 *  - OTP via Faraz SMS (ippanel.com)
 *  - Leaderboard (shared data)
 */

const express = require("express");
const cors = require("cors");
const fs = require("fs");
const path = require("path");
const https = require("https");

const app = express();
app.use(cors());
app.use(express.json({ limit: "10mb" }));

// ─── CONFIG ───────────────────────────────────────────────────────────────────
const CONFIG = {
  PORT: process.env.PORT || 3001,
  ANTHROPIC_API_KEY: process.env.ANTHROPIC_API_KEY || "YOUR_ANTHROPIC_API_KEY_HERE",
  FARAZ_USERNAME: process.env.FARAZ_USERNAME || "",
  FARAZ_PASSWORD: process.env.FARAZ_PASSWORD || "",
  FARAZ_FROM: process.env.FARAZ_FROM || "3000xxxxx",
  FARAZ_PATTERN: process.env.FARAZ_PATTERN || "your_pattern_code",
  DATA_DIR: process.env.DATA_DIR || path.join(__dirname, "data"),
  SECRET_TOKEN: process.env.SECRET_TOKEN || "change_this_secret_token_123",
};

// ─── STORAGE (File-based, replace with Redis/DB in production) ────────────────
if (!fs.existsSync(CONFIG.DATA_DIR)) fs.mkdirSync(CONFIG.DATA_DIR, { recursive: true });
if (!fs.existsSync(path.join(CONFIG.DATA_DIR, "shared"))) fs.mkdirSync(path.join(CONFIG.DATA_DIR, "shared"));
if (!fs.existsSync(path.join(CONFIG.DATA_DIR, "users"))) fs.mkdirSync(path.join(CONFIG.DATA_DIR, "users"));

function safeKey(key) {
  return key.replace(/[^a-zA-Z0-9_\-:.]/g, "_");
}

function getFilePath(key, shared, userId) {
  const k = safeKey(key);
  if (shared) return path.join(CONFIG.DATA_DIR, "shared", `${k}.json`);
  return path.join(CONFIG.DATA_DIR, "users", safeKey(userId), `${k}.json`);
}

function storageGet(key, shared, userId) {
  try {
    const fp = getFilePath(key, shared, userId);
    if (!fs.existsSync(fp)) return null;
    return { key, value: fs.readFileSync(fp, "utf8"), shared };
  } catch { return null; }
}

function storageSet(key, value, shared, userId) {
  try {
    const fp = getFilePath(key, shared, userId);
    fs.mkdirSync(path.dirname(fp), { recursive: true });
    fs.writeFileSync(fp, String(value), "utf8");
    return { key, value, shared };
  } catch { return null; }
}

function storageDelete(key, shared, userId) {
  try {
    const fp = getFilePath(key, shared, userId);
    if (fs.existsSync(fp)) fs.unlinkSync(fp);
    return { key, deleted: true, shared };
  } catch { return null; }
}

function storageList(prefix, shared, userId) {
  try {
    const dir = shared
      ? path.join(CONFIG.DATA_DIR, "shared")
      : path.join(CONFIG.DATA_DIR, "users", safeKey(userId));
    if (!fs.existsSync(dir)) return { keys: [], prefix, shared };
    const files = fs.readdirSync(dir).filter(f => f.endsWith(".json"));
    const p = safeKey(prefix || "");
    const keys = files
      .map(f => f.replace(/\.json$/, ""))
      .filter(k => !p || k.startsWith(p))
      .map(k => k.replace(/_/g, ":")); // restore colons
    return { keys, prefix, shared };
  } catch { return { keys: [], prefix, shared }; }
}

// ─── OTP STORE (in-memory, expires in 5 min) ─────────────────────────────────
const otpStore = new Map();

function storeOtp(phone, code) {
  otpStore.set(phone, { code, expires: Date.now() + 5 * 60 * 1000 });
}

function verifyOtp(phone, code) {
  const entry = otpStore.get(phone);
  if (!entry) return false;
  if (Date.now() > entry.expires) { otpStore.delete(phone); return false; }
  if (entry.code !== code) return false;
  otpStore.delete(phone);
  return true;
}

// ─── FARAZ SMS ────────────────────────────────────────────────────────────────
async function sendFarazSMS(phone, code) {
  if (!CONFIG.FARAZ_USERNAME || CONFIG.FARAZ_USERNAME === "") {
    // Mock mode: just log
    console.log(`[OTP MOCK] Phone: ${phone} | Code: ${code}`);
    return true;
  }
  return new Promise((resolve) => {
    const body = JSON.stringify({
      op: "pattern",
      user: CONFIG.FARAZ_USERNAME,
      pass: CONFIG.FARAZ_PASSWORD,
      fromNum: CONFIG.FARAZ_FROM,
      toNum: phone,
      patternCode: CONFIG.FARAZ_PATTERN,
      inputData: [{ "verification-code": code }],
    });
    const options = {
      hostname: "api2.ippanel.com",
      path: "/api/v1/sms/pattern/normal/send",
      method: "POST",
      headers: { "Content-Type": "application/json", "Content-Length": Buffer.byteLength(body) },
    };
    const req = https.request(options, (res) => {
      let data = "";
      res.on("data", d => data += d);
      res.on("end", () => {
        try {
          const r = JSON.parse(data);
          console.log("[Faraz SMS]", r);
          resolve(r.code === "OK" || r.status === 0);
        } catch { resolve(false); }
      });
    });
    req.on("error", e => { console.error("[Faraz SMS Error]", e); resolve(false); });
    req.write(body);
    req.end();
  });
}

// ─── AUTH MIDDLEWARE ──────────────────────────────────────────────────────────
// Simple phone-based auth (stateless - phone stored in each request)
// In production, use JWT tokens

// ─── ROUTES ───────────────────────────────────────────────────────────────────

// Health check
app.get("/health", (req, res) => res.json({ ok: true, version: "1.0.0" }));

// Send OTP
app.post("/api/otp/send", async (req, res) => {
  try {
    const { phone } = req.body;
    if (!phone || !/^09\d{9}$/.test(phone)) {
      return res.status(400).json({ error: "شماره موبایل معتبر نیست" });
    }
    const code = String(Math.floor(10000 + Math.random() * 90000));
    storeOtp(phone, code);
    const sent = await sendFarazSMS(phone, code);
    // In mock mode, return code (remove in production!)
    if (!CONFIG.FARAZ_USERNAME) {
      return res.json({ ok: true, mock: true, code }); // Remove 'code' in production!
    }
    res.json({ ok: sent });
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: "خطا در ارسال SMS" });
  }
});

// Verify OTP & get session token
app.post("/api/otp/verify", (req, res) => {
  try {
    const { phone, code } = req.body;
    if (!phone || !code) return res.status(400).json({ error: "اطلاعات ناقص" });
    const valid = verifyOtp(phone, code);
    if (!valid) return res.status(401).json({ error: "کد اشتباه یا منقضی شده" });
    // Simple token: base64(phone:timestamp:secret) - use JWT in production
    const token = Buffer.from(`${phone}:${Date.now()}:${CONFIG.SECRET_TOKEN}`).toString("base64");
    res.json({ ok: true, token, phone });
  } catch (e) {
    res.status(500).json({ error: "خطا در تأیید کد" });
  }
});

// Decode token helper
function decodeToken(token) {
  try {
    const decoded = Buffer.from(token, "base64").toString("utf8");
    const [phone, , secret] = decoded.split(":");
    if (secret !== CONFIG.SECRET_TOKEN) return null;
    return phone;
  } catch { return null; }
}

// Storage API
app.post("/api/storage/get", (req, res) => {
  const { key, shared, token } = req.body;
  const userId = shared ? null : decodeToken(token);
  if (!shared && !userId) return res.status(401).json({ error: "Unauthorized" });
  const result = storageGet(key, shared, userId);
  res.json({ result });
});

app.post("/api/storage/set", (req, res) => {
  const { key, value, shared, token } = req.body;
  const userId = shared ? null : decodeToken(token);
  if (!shared && !userId) return res.status(401).json({ error: "Unauthorized" });
  const result = storageSet(key, value, shared, userId);
  res.json({ result });
});

app.post("/api/storage/delete", (req, res) => {
  const { key, shared, token } = req.body;
  const userId = decodeToken(token);
  if (!userId) return res.status(401).json({ error: "Unauthorized" });
  const result = storageDelete(key, shared, userId);
  res.json({ result });
});

app.post("/api/storage/list", (req, res) => {
  const { prefix, shared, token } = req.body;
  const userId = shared ? null : decodeToken(token);
  if (!shared && !userId) return res.status(401).json({ error: "Unauthorized" });
  const result = storageList(prefix, shared, userId);
  res.json({ result });
});

// Anthropic API Proxy (keeps API key server-side)
app.post("/api/ai/chat", async (req, res) => {
  try {
    const { model, max_tokens, messages, system } = req.body;
    const body = JSON.stringify({
      model: model || "claude-sonnet-4-6",
      max_tokens: max_tokens || 1000,
      messages,
      ...(system ? { system } : {}),
    });
    const options = {
      hostname: "api.anthropic.com",
      path: "/v1/messages",
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-api-key": CONFIG.ANTHROPIC_API_KEY,
        "anthropic-version": "2023-06-01",
        "Content-Length": Buffer.byteLength(body),
      },
    };
    const apiReq = https.request(options, (apiRes) => {
      let data = "";
      apiRes.on("data", d => data += d);
      apiRes.on("end", () => {
        try { res.json(JSON.parse(data)); }
        catch { res.status(500).json({ error: "Invalid AI response" }); }
      });
    });
    apiReq.on("error", e => { console.error(e); res.status(500).json({ error: "AI API Error" }); });
    apiReq.write(body);
    apiReq.end();
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: "Server Error" });
  }
});

app.listen(CONFIG.PORT, () => {
  console.log(`✅ KetóFit Server running on port ${CONFIG.PORT}`);
  console.log(`📱 SMS Mode: ${CONFIG.FARAZ_USERNAME ? "Faraz SMS (Real)" : "Mock (Console)"}`);
  console.log(`🤖 AI: ${CONFIG.ANTHROPIC_API_KEY !== "YOUR_ANTHROPIC_API_KEY_HERE" ? "Configured" : "⚠️ Set ANTHROPIC_API_KEY"}`);
});
