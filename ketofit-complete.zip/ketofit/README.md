# 🥑 کتوفیت — راهنمای کامل ساخت APK اندروید

## ساختار پروژه

```
ketofit/
├── backend/          ← سرور Node.js
│   ├── server.js
│   ├── package.json
│   └── .env.example
└── frontend/         ← اپ React + Capacitor
    ├── src/App.jsx
    ├── public/
    ├── capacitor.config.ts
    └── package.json
```

---

## مرحله ۱: پیش‌نیازها

روی سیستم نصب کن:
- **Node.js 18+** → https://nodejs.org
- **JDK 17** → https://adoptium.net
- **Android Studio** → https://developer.android.com/studio

بعد از نصب Android Studio:
- Android SDK (API 34) نصب کن
- در PATH این رو اضافه کن:
  ```
  ANDROID_HOME=C:\Users\<you>\AppData\Local\Android\Sdk   (Windows)
  ANDROID_HOME=/Users/<you>/Library/Android/sdk            (Mac)
  ```

---

## مرحله ۲: راه‌اندازی Backend

### روی سرور (Ubuntu/VPS):

```bash
cd backend
npm install

# فایل .env بساز
cp .env.example .env
nano .env
```

فایل `.env` رو پر کن:
```env
PORT=3001
ANTHROPIC_API_KEY=sk-ant-xxxxxxxxxxxxxxxx  # از console.anthropic.com
SECRET_TOKEN=یک_رشته_تصادفی_قوی_بذار_اینجا

# اگه Faraz SMS داری:
FARAZ_USERNAME=your_username
FARAZ_PASSWORD=your_password
FARAZ_FROM=3000xxxxx
FARAZ_PATTERN=your_pattern_code
```

### اجرای سرور:

```bash
# نصب pm2 برای اجرای دائمی
npm install -g pm2

# اجرا
pm2 start server.js --name ketofit-backend
pm2 save
pm2 startup

# لاگ‌ها
pm2 logs ketofit-backend
```

### باز کردن پورت فایروال:
```bash
ufw allow 3001
```

---

## مرحله ۳: تنظیم Frontend

فایل `frontend/src/App.jsx` رو باز کن، خط اول رو ویرایش کن:

```javascript
// آدرس سرورت رو اینجا بذار
const API_BASE = "https://YOUR_SERVER_IP:3001";
// مثال: const API_BASE = "https://185.100.200.50:3001";
// یا دامنه: const API_BASE = "https://api.ketofit.ir";
```

---

## مرحله ۴: Build اپ React

```bash
cd frontend
npm install
npm run build
```

---

## مرحله ۵: Capacitor + Android

```bash
# داخل پوشه frontend:
npx cap init "کتوفیت" "app.ketofit.ir" --web-dir build
npx cap add android
npx cap sync android
```

---

## مرحله ۶: ساخت APK با Android Studio

```bash
npx cap open android
```

در Android Studio:
1. **Build** → **Generate Signed Bundle/APK**
2. APK رو انتخاب کن
3. Keystore بساز (اگه نداری):
   - Key store path: هرجایی ذخیره کن
   - Password: یه رمز قوی
   - Key alias: ketofit
4. **release** رو انتخاب کن
5. **Finish**

فایل APK در:
```
android/app/build/outputs/apk/release/app-release.apk
```

### یا APK debug (بدون sign):
```bash
cd android
./gradlew assembleDebug
# فایل در: android/app/build/outputs/apk/debug/app-debug.apk
```

---

## مرحله ۷: نصب APK روی گوشی

```bash
# با ADB:
adb install app-release.apk

# یا مستقیماً فایل رو به گوشی منتقل کن
# در گوشی: تنظیمات → امنیت → نصب از منابع ناشناس
```

---

## مرحله ۸: HTTPS برای Backend (مهم!)

اپ اندروید برای درخواست‌های HTTP نیاز به تنظیم داره. دو راه:

### راه ۱: دامنه با SSL (توصیه‌شده)
```bash
# نصب Nginx + Certbot
apt install nginx certbot python3-certbot-nginx
certbot --nginx -d api.ketofit.ir

# تنظیم Nginx proxy:
nano /etc/nginx/sites-available/ketofit
```

```nginx
server {
    listen 443 ssl;
    server_name api.ketofit.ir;
    
    location / {
        proxy_pass http://localhost:3001;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
    }
}
```

### راه ۲: بدون HTTPS (فقط برای تست)

در `android/app/src/main/res/xml/network_security_config.xml`:
```xml
<?xml version="1.0" encoding="utf-8"?>
<network-security-config>
    <domain-config cleartextTrafficPermitted="true">
        <domain includeSubdomains="true">YOUR_SERVER_IP</domain>
    </domain-config>
</network-security-config>
```

در `android/app/src/main/AndroidManifest.xml` اضافه کن:
```xml
android:networkSecurityConfig="@xml/network_security_config"
```

---

## مرحله ۹: آیکون اپ (اختیاری)

```bash
# نصب capacitor assets
npm install -g @capacitor/assets

# عکس ۱۰۲۴x۱۰۲۴ px با نام icon.png بذار در assets/
npx @capacitor/assets generate
```

---

## خلاصه سریع (بعد از تنظیم اولیه)

```bash
# هر بار که کد رو تغییر دادی:
cd frontend
npm run build
npx cap sync android
cd android && ./gradlew assembleRelease
```

---

## عیب‌یابی

| مشکل | راه‌حل |
|------|---------|
| `Network Error` | آدرس API_BASE رو چک کن |
| `CLEARTEXT not permitted` | HTTPS اضافه کن یا network_security_config |
| `SDK not found` | ANDROID_HOME رو تنظیم کن |
| `OTP نمیاد` | در حالت mock کد در لاگ سرور چاپ میشه |
| `AI کار نمیکنه` | ANTHROPIC_API_KEY رو چک کن |

---

## سوالات شایع

**چطور API key رو ایمن نگه‌دارم؟**
کلید فقط در `.env` سرور هست، هرگز به frontend نمیرسه.

**دیتا کجا ذخیره میشه؟**
در پوشه `backend/data/` به صورت فایل JSON. برای production از PostgreSQL یا MongoDB استفاده کن.

**چطور به Play Store بفرستم؟**
APK رو باید sign کنی (مرحله ۶) و یه حساب Google Play Developer ($25) بسازی.
