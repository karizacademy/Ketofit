#!/bin/bash
# build-apk.sh — ساخت سریع APK کتوفیت
# chmod +x build-apk.sh && ./build-apk.sh

set -e
echo "🥑 Building KetóFit APK..."

cd "$(dirname "$0")/frontend"

echo "📦 Installing dependencies..."
npm install --silent

echo "🔨 Building React app..."
npm run build

echo "🔄 Syncing Capacitor..."
npx cap sync android

echo "🤖 Building APK..."
cd android
./gradlew assembleDebug --quiet

echo ""
echo "✅ APK ready:"
echo "   android/app/build/outputs/apk/debug/app-debug.apk"
echo ""
echo "📱 Install with: adb install android/app/build/outputs/apk/debug/app-debug.apk"
