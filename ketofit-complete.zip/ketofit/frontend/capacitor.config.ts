import { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'app.ketofit.ir',
  appName: 'کتوفیت',
  webDir: 'build',
  server: {
    androidScheme: 'https',
    // در محیط توسعه: آدرس سرور لوکال
    // برای production: حذف کن تا از فایل‌های local استفاده کنه
    // url: 'http://10.0.2.2:3000', // فقط برای دیباگ
  },
  android: {
    allowMixedContent: true,
    captureInput: true,
    webContentsDebuggingEnabled: false, // true فقط برای دیباگ
  },
  plugins: {
    SplashScreen: {
      launchShowDuration: 2000,
      backgroundColor: '#16201A',
      showSpinner: false,
    },
  },
};

export default config;
