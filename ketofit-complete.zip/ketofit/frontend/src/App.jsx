import React, { useState, useEffect, useCallback, useRef } from "react";

// ─── BACKEND CONFIG ───────────────────────────────────────────────────────────
// آدرس سرور بکند خودت رو اینجا بذار
const API_BASE = process.env.REACT_APP_API_URL || "https://YOUR_SERVER_IP:3001";

// ─── DESIGN TOKENS ────────────────────────────────────────────────────────────
const C = {
  bg: "#16201A", panel: "#1F2B22", panelLight: "#28392C",
  cream: "#F3ECDD", avocado: "#9CB380", avocadoDark: "#6E8A55",
  fat: "#E0954A", fatDark: "#C97A33", danger: "#D9694F", muted: "#8C9A8A",
};

const toFa = (n) => String(n).replace(/[0-9]/g, (d) => "۰۱۲۳۴۵۶۷۸۹"[d]);
function fmt(n, d = 1) {
  if (n === null || n === undefined || isNaN(n)) return "—";
  return toFa(Number(n).toFixed(d));
}
function toEn(s) { return String(s).replace(/[۰-۹]/g, d => "۰۱۲۳۴۵۶۷۸۹".indexOf(d)); }

// ─── CALC HELPERS ─────────────────────────────────────────────────────────────
function calcBMR({ gender, weight, height, age }) {
  const base = 10 * weight + 6.25 * height - 5 * age;
  return gender === "male" ? base + 5 : base - 161;
}
function activityFactor(level) { return { low: 1.2, medium: 1.45, high: 1.7 }[level] || 1.3; }
function calcTargets(profile) {
  const bmr = calcBMR(profile);
  const tdee = bmr * activityFactor(profile.activity);
  const intensityMap = { easy: 0.9, moderate: 0.8, rapid: 0.7, vigorous: 0.6 };
  const intensityFactor = profile.goal === "gain" ? 1.1 : (profile.goal === "maintain" ? 1 : (intensityMap[profile.dietIntensity] || 0.8));
  const calories = Math.round(tdee * intensityFactor);
  const carbsG = 25;
  const proteinG = Math.round((calories * 0.25) / 4);
  const fatG = Math.round((calories - carbsG * 4 - proteinG * 4) / 9);
  return { calories, carbsG, proteinG, fatG };
}

// ─── STORAGE (via Backend API) ────────────────────────────────────────────────
let authToken = null;
function setAuthToken(t) { authToken = t; }

async function storageGet(key, shared = false) {
  try {
    const r = await fetch(`${API_BASE}/api/storage/get`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ key, shared, token: authToken }),
    });
    const data = await r.json();
    return data.result;
  } catch { return null; }
}

async function storageSet(key, value, shared = false) {
  try {
    const r = await fetch(`${API_BASE}/api/storage/set`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ key, value, shared, token: authToken }),
    });
    const data = await r.json();
    return data.result;
  } catch { return null; }
}

async function storageList(prefix, shared = false) {
  try {
    const r = await fetch(`${API_BASE}/api/storage/list`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ prefix, shared, token: authToken }),
    });
    const data = await r.json();
    return data.result;
  } catch { return null; }
}

async function getJSON(key, shared = false) {
  try { const r = await storageGet(key, shared); return r ? JSON.parse(r.value) : null; }
  catch { return null; }
}
async function setJSON(key, value, shared = false) {
  try { await storageSet(key, JSON.stringify(value), shared); return true; }
  catch { return false; }
}

// ─── OTP via Backend ──────────────────────────────────────────────────────────
async function sendOTP(phone) {
  const r = await fetch(`${API_BASE}/api/otp/send`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ phone }),
  });
  const data = await r.json();
  // In mock mode, server returns the code (remove in production)
  return data;
}

async function verifyOTP(phone, code) {
  const r = await fetch(`${API_BASE}/api/otp/verify`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ phone, code }),
  });
  const data = await r.json();
  if (data.ok && data.token) {
    setAuthToken(data.token);
    // Save token for next session
    localStorage.setItem("ketofit_token", data.token);
    localStorage.setItem("ketofit_phone", phone);
  }
  return data;
}

// ─── AI PLAN (via Backend proxy) ──────────────────────────────────────────────
async function generatePlan(profile, targets) {
  const foodLabel = (profile.foodPrefs || []).join("، ") || "همه‌چیز";
  const prompt = `تو یک متخصص تغذیه کتوژنیک فارسی‌زبان هستی. برای کاربر زیر یک برنامه غذایی روزانه کتوژنیک واقعی و قابل اجرا در ایران بنویس.

مشخصات: جنسیت ${profile.gender === "male" ? "مرد" : "زن"}، سن ${profile.age}، قد ${profile.height}سانت، وزن ${profile.weight}کیلو، هدف ${profile.goal === "loss" ? "کاهش وزن" : profile.goal === "gain" ? "افزایش وزن" : "حفظ وزن"}، فعالیت ${profile.activity === "low" ? "کم" : profile.activity === "high" ? "زیاد" : "متوسط"}، ترجیح غذایی: ${foodLabel}

اهداف روزانه: کالری ${targets.calories}، چربی ${targets.fatG}گرم، پروتئین ${targets.proteinG}گرم، کربو ${targets.carbsG}گرم.

برای هر وعده دقیقاً ۴ گزینه متفاوت پیشنهاد بده. فقط JSON خالص بدون backtick، دقیقا با این ساختار:
{"meals":[
  {"name":"صبحانه","options":[{"items":["..."],"calories":0},{"items":["..."],"calories":0},{"items":["..."],"calories":0},{"items":["..."],"calories":0}]},
  {"name":"میان‌وعده","options":[{"items":["..."],"calories":0},{"items":["..."],"calories":0},{"items":["..."],"calories":0},{"items":["..."],"calories":0}]},
  {"name":"ناهار","options":[{"items":["..."],"calories":0},{"items":["..."],"calories":0},{"items":["..."],"calories":0},{"items":["..."],"calories":0}]},
  {"name":"میان‌وعده","options":[{"items":["..."],"calories":0},{"items":["..."],"calories":0},{"items":["..."],"calories":0},{"items":["..."],"calories":0}]},
  {"name":"شام","options":[{"items":["..."],"calories":0},{"items":["..."],"calories":0},{"items":["..."],"calories":0},{"items":["..."],"calories":0}]}
],"tips":["نکته۱","نکته۲","نکته۳"]}`;

  const response = await fetch(`${API_BASE}/api/ai/chat`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      model: "claude-sonnet-4-6",
      max_tokens: 3000,
      messages: [{ role: "user", content: prompt }],
    }),
  });
  const data = await response.json();
  const text = data.content.map(c => c.text || "").join("");
  return JSON.parse(text.replace(/```json|```/g, "").trim());
}

// ─── AI CONSULT CHAT (via Backend proxy) ─────────────────────────────────────
async function sendConsultMessage(history, profile, targets) {
  const system = `تو "دستیار کتوفیت" هستی، یک مشاور تغذیه و رژیم کتوژنیک فارسی‌زبان، دوستانه و دقیق.
مشخصات کاربر: جنسیت ${profile.gender === "male" ? "مرد" : "زن"}، سن ${profile.age}، قد ${profile.height}سانت، وزن ${profile.weight}کیلو، هدف ${profile.goal === "loss" ? "کاهش وزن" : profile.goal === "gain" ? "افزایش وزن" : "حفظ وزن"}.
اهداف روزانه: کالری ${targets.calories}، چربی ${targets.fatG}گرم، پروتئین ${targets.proteinG}گرم، کربو ${targets.carbsG}گرم.
پاسخ‌ها رو کوتاه، کاربردی و به فارسی بده. اگه سوال خارج از حوزه تغذیه/سلامت/کتو بود مودبانه بگو تخصصت تغذیه کتوژنیکه.`;

  const response = await fetch(`${API_BASE}/api/ai/chat`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      model: "claude-sonnet-4-6",
      max_tokens: 600,
      system,
      messages: history.map(m => ({ role: m.role, content: m.content })),
    }),
  });
  const data = await response.json();
  return data.content.map(c => c.text || "").join("");
}

// ─── UI ATOMS ─────────────────────────────────────────────────────────────────
function Btn({ children, onClick, variant = "primary", disabled, style }) {
  const bg = variant === "primary" ? C.fat : variant === "ghost" ? "transparent" : C.panelLight;
  const color = variant === "primary" ? "#1A1208" : C.cream;
  const border = variant === "ghost" ? `1px solid ${C.avocadoDark}55` : variant === "secondary" ? `1px solid ${C.avocadoDark}55` : "none";
  return (
    <button onClick={onClick} disabled={disabled} style={{
      background: disabled ? "#333" : bg, color: disabled ? "#666" : color,
      border, borderRadius: 14, padding: "13px 20px", fontSize: 15, fontWeight: 700,
      cursor: disabled ? "not-allowed" : "pointer", transition: "transform .12s",
      fontFamily: "inherit", width: "100%", ...style,
    }}
      onMouseDown={e => !disabled && (e.currentTarget.style.transform = "scale(0.97)")}
      onMouseUp={e => (e.currentTarget.style.transform = "scale(1)")}
    >{children}</button>
  );
}

function Card({ children, style }) {
  return <div style={{ background: C.panel, borderRadius: 22, padding: 24, border: `1px solid ${C.avocadoDark}33`, ...style }}>{children}</div>;
}

function StepBar({ current, total }) {
  return (
    <div style={{ display: "flex", gap: 6, marginBottom: 24 }}>
      {Array.from({ length: total }).map((_, i) => (
        <div key={i} style={{ flex: 1, height: 4, borderRadius: 99, background: i <= current ? C.fat : `${C.avocadoDark}44`, transition: "background .4s" }} />
      ))}
    </div>
  );
}

function OptionCard({ icon, label, sublabel, badge, badgeColor, selected, onClick, multi }) {
  return (
    <div onClick={onClick} style={{
      background: selected ? `${C.fat}1A` : C.panelLight,
      border: `2px solid ${selected ? C.fat : C.avocadoDark + "33"}`,
      borderRadius: 16, padding: "14px 16px", cursor: "pointer",
      display: "flex", alignItems: "center", gap: 12, transition: "border .2s, background .2s",
    }}>
      {icon && <div style={{ fontSize: 26, lineHeight: 1, minWidth: 32, textAlign: "center" }}>{icon}</div>}
      <div style={{ flex: 1 }}>
        <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
          {badge && <span style={{ background: badgeColor || C.fat, color: "#fff", fontSize: 10, fontWeight: 700, borderRadius: 6, padding: "1px 6px" }}>{badge}</span>}
          <span style={{ color: selected ? C.fat : C.cream, fontWeight: 700, fontSize: 14 }}>{label}</span>
        </div>
        {sublabel && <div style={{ color: C.muted, fontSize: 11.5, marginTop: 2 }}>{sublabel}</div>}
      </div>
      <div style={{
        width: 20, height: 20, borderRadius: multi ? 6 : "50%",
        border: `2px solid ${selected ? C.fat : C.avocadoDark + "66"}`,
        background: selected ? C.fat : "transparent",
        display: "flex", alignItems: "center", justifyContent: "center", transition: "all .2s", flexShrink: 0,
      }}>
        {selected && <div style={{ width: 8, height: 8, borderRadius: multi ? 2 : "50%", background: "#1A1208" }} />}
      </div>
    </div>
  );
}

function Stepper({ value, onChange, min, max, unit, sublabel }) {
  return (
    <div style={{ textAlign: "center" }}>
      {sublabel && <div style={{ color: C.muted, fontSize: 12, marginBottom: 16 }}>{sublabel}</div>}
      <div style={{ display: "flex", alignItems: "center", justifyContent: "center" }}>
        <button onClick={() => onChange(Math.max(min, value - 1))} style={{
          width: 52, height: 52, borderRadius: "50%", border: `2px solid ${C.avocadoDark}55`,
          background: C.panelLight, color: C.cream, fontSize: 24, cursor: "pointer", fontFamily: "inherit",
        }}>−</button>
        <div style={{ width: 140, textAlign: "center" }}>
          <span style={{ fontSize: 56, fontWeight: 800, color: C.fat, lineHeight: 1 }}>{toFa(value)}</span>
          <span style={{ fontSize: 14, color: C.muted, marginRight: 6 }}>{unit}</span>
        </div>
        <button onClick={() => onChange(Math.min(max, value + 1))} style={{
          width: 52, height: 52, borderRadius: "50%", border: `2px solid ${C.avocadoDark}55`,
          background: C.panelLight, color: C.cream, fontSize: 24, cursor: "pointer", fontFamily: "inherit",
        }}>+</button>
      </div>
    </div>
  );
}

// ─── LOGIN WITH PHONE + OTP ───────────────────────────────────────────────────
function LoginScreen({ onLogin }) {
  const [phase, setPhase] = useState("phone");
  const [phone, setPhone] = useState("");
  const [otp, setOtp] = useState(["", "", "", "", ""]);
  const [sending, setSending] = useState(false);
  const [verifying, setVerifying] = useState(false);
  const [error, setError] = useState("");
  const [countdown, setCountdown] = useState(0);
  const [mockCode, setMockCode] = useState(""); // فقط در حالت mock
  const refs = [useRef(), useRef(), useRef(), useRef(), useRef()];

  useEffect(() => {
    if (countdown > 0) { const t = setTimeout(() => setCountdown(c => c - 1), 1000); return () => clearTimeout(t); }
  }, [countdown]);

  // بررسی توکن ذخیره‌شده
  useEffect(() => {
    const saved = localStorage.getItem("ketofit_token");
    const savedPhone = localStorage.getItem("ketofit_phone");
    if (saved && savedPhone) {
      setAuthToken(saved);
      onLogin(savedPhone);
    }
  }, []); // eslint-disable-line

  const sendCode = async () => {
    const cleaned = toEn(phone).replace(/\D/g, "");
    if (cleaned.length !== 11 || !cleaned.startsWith("09")) { setError("شماره موبایل معتبر نیست"); return; }
    setSending(true); setError("");
    try {
      const result = await sendOTP(cleaned);
      if (!result.ok) { setError("خطا در ارسال کد. دوباره تلاش کن."); setSending(false); return; }
      // Mock mode: سرور کد رو برمیگردونه
      if (result.mock && result.code) {
        setMockCode(result.code);
        console.log(`[کد OTP دمو]: ${result.code}`);
      }
      setSending(false);
      setPhase("otp");
      setCountdown(120);
      setTimeout(() => refs[0].current?.focus(), 100);
    } catch {
      setError("سرور در دسترس نیست. آدرس API را بررسی کنید.");
      setSending(false);
    }
  };

  const handleOtpChange = (i, val) => {
    const v = toEn(val).replace(/\D/g, "").slice(-1);
    const next = [...otp]; next[i] = v; setOtp(next);
    if (v && i < 4) refs[i + 1].current?.focus();
    if (!v && i > 0) refs[i - 1].current?.focus();
  };

  const verifyCode = async () => {
    const entered = otp.join("");
    if (entered.length < 5) { setError("کد ۵ رقمی را وارد کنید"); return; }
    setVerifying(true); setError("");
    const cleaned = toEn(phone).replace(/\D/g, "");
    const result = await verifyOTP(cleaned, entered);
    if (result.ok) {
      await onLogin(cleaned);
    } else {
      setError("کد وارد شده اشتباه یا منقضی شده");
      setVerifying(false);
    }
  };

  const resend = async () => {
    if (countdown > 0) return;
    const cleaned = toEn(phone).replace(/\D/g, "");
    setOtp(["", "", "", "", ""]);
    const result = await sendOTP(cleaned);
    if (result.mock && result.code) setMockCode(result.code);
    setCountdown(120);
    setTimeout(() => refs[0].current?.focus(), 100);
  };

  return (
    <div style={{ minHeight: "100vh", display: "flex", alignItems: "center", justifyContent: "center", padding: 20 }}>
      <div style={{ width: 380, maxWidth: "100%" }}>
        <div style={{ textAlign: "center", marginBottom: 32 }}>
          <div style={{ fontSize: 56, marginBottom: 12 }}>🥑</div>
          <h1 style={{ color: C.cream, fontSize: 28, margin: 0, fontWeight: 800 }}>کتوفیت</h1>
          <p style={{ color: C.muted, fontSize: 13, marginTop: 8 }}>برنامه‌ریز هوشمند رژیم کتوژنیک</p>
        </div>
        <Card>
          {phase === "phone" ? (
            <>
              <div style={{ color: C.cream, fontWeight: 700, fontSize: 17, marginBottom: 6 }}>ورود با شماره موبایل</div>
              <div style={{ color: C.muted, fontSize: 13, marginBottom: 20 }}>کد تأیید ۵ رقمی برای شما ارسال می‌شود</div>
              <div style={{ marginBottom: 14 }}>
                <div style={{ color: C.muted, fontSize: 12, marginBottom: 6 }}>شماره موبایل</div>
                <input value={phone} onChange={e => setPhone(e.target.value)}
                  placeholder="۰۹۱۲۳۴۵۶۷۸۹" type="tel" maxLength={11}
                  style={{ width: "100%", background: C.panelLight, border: `1px solid ${C.avocadoDark}55`, color: C.cream, borderRadius: 12, padding: "12px 14px", fontSize: 16, outline: "none", fontFamily: "inherit", boxSizing: "border-box", textAlign: "center", letterSpacing: 2 }}
                  onKeyDown={e => e.key === "Enter" && sendCode()}
                />
              </div>
              {error && <div style={{ color: C.danger, fontSize: 13, marginBottom: 10 }}>{error}</div>}
              <Btn onClick={sendCode} disabled={sending}>{sending ? "در حال ارسال..." : "ارسال کد تأیید 📲"}</Btn>
              <div style={{ marginTop: 14, background: `${C.avocadoDark}22`, borderRadius: 10, padding: "10px 14px" }}>
                <div style={{ color: C.avocado, fontSize: 11, fontWeight: 700, marginBottom: 4 }}>🔧 راهنما</div>
                <div style={{ color: C.muted, fontSize: 11 }}>اگه Faraz SMS تنظیم نشده، کد در Console سرور نمایش داده می‌شود.</div>
              </div>
            </>
          ) : (
            <>
              <div style={{ textAlign: "center", marginBottom: 20 }}>
                <div style={{ color: C.cream, fontWeight: 700, fontSize: 17, marginBottom: 6 }}>کد تأیید را وارد کنید</div>
                <div style={{ color: C.muted, fontSize: 13 }}>کد ۵ رقمی ارسال شده به<br /><span style={{ color: C.fat, fontWeight: 700 }}>{phone}</span></div>
              </div>
              {mockCode && (
                <div style={{ background: `${C.fat}22`, borderRadius: 10, padding: "8px 14px", marginBottom: 14, textAlign: "center" }}>
                  <div style={{ color: C.fat, fontSize: 11, fontWeight: 700 }}>🔧 حالت دمو - کد: {mockCode}</div>
                </div>
              )}
              <div style={{ display: "flex", gap: 8, justifyContent: "center", marginBottom: 20, direction: "ltr" }}>
                {otp.map((v, i) => (
                  <input key={i} ref={refs[i]} value={v} maxLength={1} type="tel"
                    onChange={e => handleOtpChange(i, e.target.value)}
                    onKeyDown={e => { if (e.key === "Backspace" && !v && i > 0) refs[i - 1].current?.focus(); }}
                    style={{ width: 48, height: 58, textAlign: "center", fontSize: 24, fontWeight: 800, background: C.panelLight, border: `2px solid ${v ? C.fat : C.avocadoDark + "55"}`, color: C.cream, borderRadius: 12, outline: "none", fontFamily: "inherit", transition: "border .2s" }}
                  />
                ))}
              </div>
              {error && <div style={{ color: C.danger, fontSize: 13, marginBottom: 10, textAlign: "center" }}>{error}</div>}
              <Btn onClick={verifyCode} disabled={verifying}>{verifying ? "در حال تأیید..." : "تأیید و ورود ✅"}</Btn>
              <div style={{ textAlign: "center", marginTop: 16 }}>
                {countdown > 0 ? (
                  <span style={{ color: C.muted, fontSize: 13 }}>ارسال مجدد تا {toFa(countdown)} ثانیه دیگر</span>
                ) : (
                  <button onClick={resend} style={{ background: "none", border: "none", color: C.avocado, fontSize: 13, cursor: "pointer", fontFamily: "inherit", fontWeight: 700 }}>ارسال مجدد کد</button>
                )}
              </div>
              <button onClick={() => { setPhase("phone"); setError(""); setOtp(["", "", "", "", ""]); setMockCode(""); }}
                style={{ background: "none", border: "none", color: C.muted, fontSize: 12, cursor: "pointer", fontFamily: "inherit", marginTop: 10, width: "100%" }}>
                ← ویرایش شماره
              </button>
            </>
          )}
        </Card>
      </div>
    </div>
  );
}

// ─── ONBOARDING ───────────────────────────────────────────────────────────────
const FOOD_OPTIONS = [
  { id: "meat", icon: "🥩", label: "گوشت قرمز" },
  { id: "chicken", icon: "🍗", label: "مرغ و پرندگان" },
  { id: "fish", icon: "🐟", label: "ماهی و غذای دریایی" },
  { id: "egg", icon: "🥚", label: "تخم‌مرغ" },
  { id: "dairy", icon: "🧀", label: "لبنیات (پنیر، خامه)" },
  { id: "vegetable", icon: "🥦", label: "سبزیجات" },
  { id: "nut", icon: "🥜", label: "آجیل و دانه‌ها" },
  { id: "olive", icon: "🫒", label: "زیتون و روغن‌های سالم" },
  { id: "avocado", icon: "🥑", label: "آووکادو" },
];

const INTENSITY_OPTIONS = [
  { id: "easy", badge: "آسان", badgeColor: "#4CAF50", icon: "😊", label: "۰.۲۵ کیلو در هفته", sublabel: "مناسب برای شروع تدریجی — کمترین محدودیت" },
  { id: "moderate", badge: "متوسط", badgeColor: "#2196F3", icon: "🙂", label: "۰.۵ کیلو در هفته", sublabel: "تعادل بین نتیجه و راحتی" },
  { id: "rapid", badge: "سریع", badgeColor: "#FF9800", icon: "😤", label: "۰.۷۵ کیلو در هفته", sublabel: "نتایج سریع‌تر با رژیم سخت‌تر" },
  { id: "vigorous", badge: "فشرده", badgeColor: "#f44336", icon: "🔥", label: "۱ کیلو در هفته", sublabel: "حداکثر کاهش وزن — نیاز به اراده قوی" },
];

const STEPS = ["gender", "goal", "intensity", "age", "height", "weight", "activity", "foodprefs", "summary"];

function Onboarding({ initial, onSave, saving }) {
  const [step, setStep] = useState(0);
  const [form, setForm] = useState(initial || {
    gender: "male", goal: "loss", dietIntensity: "moderate",
    age: 30, height: 170, weight: 80, activity: "medium",
    foodPrefs: ["meat", "chicken", "egg", "dairy", "vegetable"],
  });

  const upd = (k, v) => setForm(f => ({ ...f, [k]: v }));
  const toggleFood = (id) => {
    const cur = form.foodPrefs || [];
    upd("foodPrefs", cur.includes(id) ? cur.filter(x => x !== id) : [...cur, id]);
  };

  const effectiveSteps = STEPS.filter(s => s !== "intensity" || form.goal === "loss");
  const effectiveStep = Math.min(step, effectiveSteps.length - 1);
  const currentStepName = effectiveSteps[effectiveStep];
  const isSummaryStep = currentStepName === "summary";

  const goNext = () => setStep(s => {
    const next = s + 1;
    if (effectiveSteps[next] === "intensity" && form.goal !== "loss") return s + 2;
    return next;
  });
  const goBack = () => setStep(s => {
    const prev = s - 1;
    if (prev >= 0 && effectiveSteps[prev] === "intensity" && form.goal !== "loss") return s - 2;
    return Math.max(0, prev);
  });

  const renderStep = () => {
    const s = effectiveSteps[effectiveStep];
    const targets = calcTargets(form);
    switch (s) {
      case "gender": return (
        <div style={{ animation: "slideIn .3s ease" }}>
          <div style={{ fontSize: 44, textAlign: "center", marginBottom: 8 }}>👤</div>
          <h2 style={{ color: C.cream, fontSize: 21, textAlign: "center", marginBottom: 6 }}>جنسیت شما چیست؟</h2>
          <p style={{ color: C.muted, textAlign: "center", fontSize: 13, marginBottom: 22 }}>برای محاسبه دقیق متابولیسم پایه</p>
          <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
            <OptionCard icon="👨" label="مرد" selected={form.gender === "male"} onClick={() => upd("gender", "male")} />
            <OptionCard icon="👩" label="زن" selected={form.gender === "female"} onClick={() => upd("gender", "female")} />
          </div>
        </div>
      );
      case "goal": return (
        <div style={{ animation: "slideIn .3s ease" }}>
          <div style={{ fontSize: 44, textAlign: "center", marginBottom: 8 }}>🎯</div>
          <h2 style={{ color: C.cream, fontSize: 21, textAlign: "center", marginBottom: 6 }}>هدف شما چیست؟</h2>
          <p style={{ color: C.muted, textAlign: "center", fontSize: 13, marginBottom: 22 }}>برنامه بر اساس هدف تنظیم می‌شود</p>
          <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
            <OptionCard icon="🔥" label="کاهش وزن" sublabel="رژیم با کسری کالری" selected={form.goal === "loss"} onClick={() => upd("goal", "loss")} />
            <OptionCard icon="⚖️" label="حفظ وزن" sublabel="حفظ ترکیب بدنی فعلی" selected={form.goal === "maintain"} onClick={() => upd("goal", "maintain")} />
            <OptionCard icon="💪" label="افزایش وزن" sublabel="عضله‌سازی و افزایش توده" selected={form.goal === "gain"} onClick={() => upd("goal", "gain")} />
          </div>
        </div>
      );
      case "intensity": return (
        <div style={{ animation: "slideIn .3s ease" }}>
          <div style={{ fontSize: 44, textAlign: "center", marginBottom: 8 }}>📊</div>
          <h2 style={{ color: C.cream, fontSize: 21, textAlign: "center", marginBottom: 6 }}>شدت برنامه کاهش وزن</h2>
          <div style={{ display: "flex", flexDirection: "column", gap: 11 }}>
            {INTENSITY_OPTIONS.map(opt => {
              const bmr = calcBMR({ ...form, age: form.age || 30, height: form.height || 170, weight: form.weight || 80 });
              const tdee = bmr * activityFactor(form.activity || "medium");
              const cal = Math.round(tdee * { easy: 0.9, moderate: 0.8, rapid: 0.7, vigorous: 0.6 }[opt.id]);
              return (
                <OptionCard key={opt.id} icon={opt.icon} badge={opt.badge} badgeColor={opt.badgeColor}
                  label={opt.label} sublabel={`${opt.sublabel} — ~${toFa(cal)} کالری`}
                  selected={form.dietIntensity === opt.id} onClick={() => upd("dietIntensity", opt.id)} />
              );
            })}
          </div>
        </div>
      );
      case "age": return (
        <div style={{ animation: "slideIn .3s ease" }}>
          <div style={{ fontSize: 44, textAlign: "center", marginBottom: 8 }}>🎂</div>
          <h2 style={{ color: C.cream, fontSize: 21, textAlign: "center", marginBottom: 24 }}>چند سالته؟</h2>
          <Stepper value={form.age} onChange={v => upd("age", v)} min={15} max={90} unit="سال" />
        </div>
      );
      case "height": return (
        <div style={{ animation: "slideIn .3s ease" }}>
          <div style={{ fontSize: 44, textAlign: "center", marginBottom: 8 }}>📏</div>
          <h2 style={{ color: C.cream, fontSize: 21, textAlign: "center", marginBottom: 24 }}>قد شما؟</h2>
          <Stepper value={form.height} onChange={v => upd("height", v)} min={140} max={220} unit="سانتی‌متر" sublabel="بدون کفش" />
        </div>
      );
      case "weight": return (
        <div style={{ animation: "slideIn .3s ease" }}>
          <div style={{ fontSize: 44, textAlign: "center", marginBottom: 8 }}>⚖️</div>
          <h2 style={{ color: C.cream, fontSize: 21, textAlign: "center", marginBottom: 24 }}>وزن فعلی شما؟</h2>
          <Stepper value={form.weight} onChange={v => upd("weight", v)} min={40} max={200} unit="کیلوگرم" sublabel="صبح ناشتا" />
        </div>
      );
      case "activity": return (
        <div style={{ animation: "slideIn .3s ease" }}>
          <div style={{ fontSize: 44, textAlign: "center", marginBottom: 8 }}>🏃</div>
          <h2 style={{ color: C.cream, fontSize: 21, textAlign: "center", marginBottom: 6 }}>سطح فعالیت روزانه؟</h2>
          <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
            <OptionCard icon="🛋️" label="کم" sublabel="کار اداری / بیشتر نشسته" selected={form.activity === "low"} onClick={() => upd("activity", "low")} />
            <OptionCard icon="🚶" label="متوسط" sublabel="پیاده‌روی روزانه، کمی ورزش" selected={form.activity === "medium"} onClick={() => upd("activity", "medium")} />
            <OptionCard icon="🏋️" label="زیاد" sublabel="ورزش منظم یا کار فیزیکی" selected={form.activity === "high"} onClick={() => upd("activity", "high")} />
          </div>
        </div>
      );
      case "foodprefs": return (
        <div style={{ animation: "slideIn .3s ease" }}>
          <div style={{ fontSize: 44, textAlign: "center", marginBottom: 8 }}>🍽️</div>
          <h2 style={{ color: C.cream, fontSize: 21, textAlign: "center", marginBottom: 6 }}>غذاهای مورد علاقه</h2>
          <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
            {FOOD_OPTIONS.map(opt => (
              <OptionCard key={opt.id} icon={opt.icon} label={opt.label} multi
                selected={(form.foodPrefs || []).includes(opt.id)} onClick={() => toggleFood(opt.id)} />
            ))}
          </div>
        </div>
      );
      case "summary": {
        const bmi = form.weight / ((form.height / 100) ** 2);
        const intensityLabel = INTENSITY_OPTIONS.find(o => o.id === form.dietIntensity)?.badge || "";
        const weeklyLoss = { easy: 0.25, moderate: 0.5, rapid: 0.75, vigorous: 1 }[form.dietIntensity] || 0.5;
        return (
          <div style={{ animation: "slideIn .3s ease" }}>
            <div style={{ fontSize: 44, textAlign: "center", marginBottom: 8 }}>✅</div>
            <h2 style={{ color: C.cream, fontSize: 21, textAlign: "center", marginBottom: 4 }}>پروفایل آماده‌ست!</h2>
            <div style={{ background: C.panelLight, borderRadius: 16, padding: 18, marginBottom: 16 }}>
              <div style={{ color: C.avocado, fontSize: 13, fontWeight: 700, marginBottom: 14 }}>🎯 اهداف روزانه شما</div>
              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 14 }}>
                {[["🔥", "کالری", targets.calories, ""], ["🥑", "چربی", targets.fatG, "گرم"], ["🥩", "پروتئین", targets.proteinG, "گرم"], ["🌿", "کربو", targets.carbsG, "گرم"]].map(([icon, label, val, unit]) => (
                  <div key={label} style={{ display: "flex", alignItems: "center", gap: 10 }}>
                    <span style={{ fontSize: 22 }}>{icon}</span>
                    <div>
                      <div style={{ color: C.fat, fontSize: 17, fontWeight: 800, lineHeight: 1 }}>{fmt(val, 0)}<span style={{ fontSize: 10, color: C.muted, fontWeight: 400, marginRight: 3 }}>{unit}</span></div>
                      <div style={{ color: C.muted, fontSize: 11 }}>{label}</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
            <div style={{ display: "flex", gap: 8, flexWrap: "wrap", marginBottom: 16 }}>
              {[
                ["📊", "شدت", intensityLabel],
                ["📏", "قد", `${toFa(form.height)}سانت`],
                ["⚖️", "وزن", `${toFa(form.weight)}کیلو`],
                form.goal === "loss" ? ["📉", "هفتگی", `${toFa(weeklyLoss)} کیلو`] : ["💪", "هدف", "حفظ/افزایش"],
              ].map(([icon, label, val]) => (
                <div key={label} style={{ flex: "1 1 70px", background: C.panelLight, borderRadius: 12, padding: "10px 8px", textAlign: "center" }}>
                  <div style={{ fontSize: 18 }}>{icon}</div>
                  <div style={{ color: C.fat, fontWeight: 700, fontSize: 13 }}>{val}</div>
                  <div style={{ color: C.muted, fontSize: 10 }}>{label}</div>
                </div>
              ))}
            </div>
            <div style={{ textAlign: "center" }}>
              <span style={{ background: `${C.avocadoDark}33`, borderRadius: 99, padding: "6px 16px", fontSize: 13, color: C.avocado }}>BMI: {fmt(bmi)}</span>
            </div>
          </div>
        );
      }
      default: return null;
    }
  };

  return (
    <div style={{ minHeight: "100vh", display: "flex", alignItems: "center", justifyContent: "center", padding: 20 }}>
      <style>{`@keyframes slideIn{from{opacity:0;transform:translateX(-20px)}to{opacity:1;transform:translateX(0)}}`}</style>
      <div style={{ width: 420, maxWidth: "100%" }}>
        <div style={{ textAlign: "center", marginBottom: 20 }}>
          <span style={{ fontSize: 26 }}>🥑</span>
          <span style={{ fontWeight: 800, fontSize: 18, color: C.cream, marginRight: 8 }}>کتوفیت</span>
        </div>
        <StepBar current={effectiveStep} total={effectiveSteps.length} />
        <Card style={{ marginBottom: 14 }}>{renderStep()}</Card>
        <div style={{ display: "flex", gap: 10 }}>
          {effectiveStep > 0 && <Btn variant="secondary" onClick={goBack} style={{ flex: 1, padding: "12px" }}>← قبلی</Btn>}
          {!isSummaryStep ? (
            <Btn onClick={goNext} style={{ flex: 2 }}>بعدی ←</Btn>
          ) : (
            <Btn onClick={() => onSave(form)} disabled={saving} style={{ flex: 2 }}>
              {saving ? "در حال ساخت برنامه... ⏳" : "🚀 شروع کتو"}
            </Btn>
          )}
        </div>
      </div>
    </div>
  );
}

// ─── WEEKLY TRACKER ───────────────────────────────────────────────────────────
function WeeklyTracker({ startDate, logs, targets }) {
  const today = new Date();
  const dayNames = ["یک‌شنبه", "دوشنبه", "سه‌شنبه", "چهارشنبه", "پنج‌شنبه", "جمعه", "شنبه"];
  const start = startDate ? new Date(startDate) : today;
  const days = Array.from({ length: 7 }, (_, i) => {
    const d = new Date(start);
    d.setDate(d.getDate() + i);
    const key = d.toISOString().slice(0, 10);
    const log = logs.find(l => new Date(l.date).toISOString().slice(0, 10) === key);
    const isToday = key === today.toISOString().slice(0, 10);
    const isPast = d < today && !isToday;
    return { date: d, key, log, isToday, isPast, dayName: dayNames[d.getDay()] };
  });
  const adherencePct = targets && logs.length > 0
    ? Math.round((logs.filter(l => Math.abs((l.caloriesEaten || 0) - targets.calories) < targets.calories * 0.15).length / logs.length) * 100) : 0;

  return (
    <Card>
      <h2 style={{ color: C.cream, fontSize: 18, marginTop: 0, marginBottom: 4 }}>📅 ردیابی هفتگی</h2>
      <p style={{ color: C.muted, fontSize: 12, marginBottom: 18 }}>شروع رژیم: {start.toLocaleDateString("fa-IR")}</p>
      <div style={{ display: "flex", gap: 8, marginBottom: 18 }}>
        {[["🔥", "روزهای ثبت‌شده", `${toFa(logs.length)} روز`], ["✅", "رعایت رژیم", `${toFa(adherencePct)}٪`]].map(([icon, label, val]) => (
          <div key={label} style={{ flex: 1, background: C.panelLight, borderRadius: 12, padding: "10px 8px", textAlign: "center" }}>
            <div style={{ fontSize: 20 }}>{icon}</div>
            <div style={{ color: C.fat, fontWeight: 700, fontSize: 13 }}>{val}</div>
            <div style={{ color: C.muted, fontSize: 10 }}>{label}</div>
          </div>
        ))}
      </div>
      <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
        {days.map(({ key, log, isToday, isPast, dayName, date }) => {
          const status = log ? "done" : isPast ? "missed" : isToday ? "today" : "upcoming";
          const statusColor = { done: C.avocado, missed: C.danger, today: C.fat, upcoming: C.muted }[status];
          const statusIcon = { done: "✅", missed: "❌", today: "▶️", upcoming: "⬜" }[status];
          const statusLabel = { done: "رعایت شد", missed: "ثبت نشد", today: "امروز", upcoming: "پیش رو" }[status];
          return (
            <div key={key} style={{ background: isToday ? `${C.fat}15` : C.panelLight, border: `1px solid ${isToday ? C.fat + "66" : C.avocadoDark + "22"}`, borderRadius: 14, padding: "12px 16px", display: "flex", alignItems: "center", justifyContent: "space-between" }}>
              <div>
                <div style={{ color: isToday ? C.fat : C.cream, fontWeight: 700, fontSize: 13 }}>{dayName} · {date.toLocaleDateString("fa-IR")}</div>
                <div style={{ color: C.muted, fontSize: 13 }}>{log ? `کالری: ${toFa(log.caloriesEaten || 0)}` : statusLabel}</div>
              </div>
              <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 2 }}>
                <span style={{ fontSize: 18 }}>{statusIcon}</span>
                <span style={{ fontSize: 9, color: statusColor }}>{statusLabel}</span>
              </div>
            </div>
          );
        })}
      </div>
    </Card>
  );
}

// ─── INVITE SCREEN ────────────────────────────────────────────────────────────
function InviteScreen({ userPhone }) {
  const [copied, setCopied] = useState(false);
  const code = "KETO" + userPhone.slice(-4);
  const link = `https://ketofit.app/join?ref=${code}`;
  const copy = () => { navigator.clipboard?.writeText(link).catch(() => {}); setCopied(true); setTimeout(() => setCopied(false), 2000); };
  const share = () => { if (navigator.share) { navigator.share({ title: "کتوفیت", text: `با این لینک ثبت‌نام کن: ${link}`, url: link }); } else copy(); };
  return (
    <Card>
      <h2 style={{ color: C.cream, fontSize: 18, marginTop: 0 }}>🎁 دعوت دوستان</h2>
      <p style={{ color: C.muted, fontSize: 12, marginBottom: 20 }}>برای هر دوستی که دعوت کنی، ۷ روز اشتراک رایگان!</p>
      <div style={{ background: C.panelLight, borderRadius: 16, padding: 18, textAlign: "center" }}>
        <div style={{ color: C.muted, fontSize: 12, marginBottom: 8 }}>کد دعوت اختصاصی شما</div>
        <div style={{ color: C.fat, fontSize: 28, fontWeight: 800, letterSpacing: 4, marginBottom: 12 }}>{code}</div>
        <div style={{ display: "flex", gap: 8 }}>
          <button onClick={copy} style={{ flex: 1, background: copied ? C.avocadoDark : C.panel, color: C.cream, border: `1px solid ${C.avocadoDark}55`, borderRadius: 10, padding: "10px 0", fontSize: 13, fontWeight: 700, cursor: "pointer", fontFamily: "inherit" }}>{copied ? "✅ کپی شد!" : "📋 کپی لینک"}</button>
          <button onClick={share} style={{ flex: 1, background: C.fat, color: "#1A1208", border: "none", borderRadius: 10, padding: "10px 0", fontSize: 13, fontWeight: 700, cursor: "pointer", fontFamily: "inherit" }}>📤 اشتراک</button>
        </div>
      </div>
    </Card>
  );
}

// ─── MEAL PHOTO UPLOAD ────────────────────────────────────────────────────────
function MealPhotoUpload({ photo, onUpload, onRemove }) {
  const inputRef = useRef();
  const handleFile = (e) => {
    const file = e.target.files?.[0]; if (!file) return;
    const reader = new FileReader();
    reader.onload = () => onUpload(reader.result);
    reader.readAsDataURL(file); e.target.value = "";
  };
  return (
    <div style={{ marginTop: 8, display: "flex", alignItems: "center", gap: 10 }}>
      <input ref={inputRef} type="file" accept="image/*" capture="environment" style={{ display: "none" }} onChange={handleFile} />
      {photo ? (
        <div style={{ position: "relative" }}>
          <img src={photo} alt="عکس وعده" style={{ width: 56, height: 56, borderRadius: 10, objectFit: "cover", border: `1px solid ${C.avocadoDark}55` }} />
          <button onClick={onRemove} style={{ position: "absolute", top: -6, right: -6, width: 18, height: 18, borderRadius: "50%", background: C.danger, color: "#fff", border: "none", fontSize: 11, lineHeight: "18px", cursor: "pointer", padding: 0 }}>✕</button>
        </div>
      ) : (
        <button onClick={() => inputRef.current?.click()} style={{ background: C.panelLight, color: C.muted, border: `1px dashed ${C.avocadoDark}66`, borderRadius: 10, padding: "8px 12px", fontSize: 11.5, cursor: "pointer", fontFamily: "inherit" }}>📷 آپلود عکس وعده</button>
      )}
    </div>
  );
}

// ─── PLAN CARD ────────────────────────────────────────────────────────────────
function PlanCard({ plan, targets, onRegenerate, loading, selections, onSelectOption, photos, onPhotoUpload, onPhotoRemove }) {
  const selectedTotal = plan ? plan.meals.reduce((sum, m, i) => {
    const opt = m.options?.[selections?.[i] ?? 0];
    return sum + (opt?.calories || 0);
  }, 0) : 0;

  return (
    <Card>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 12 }}>
        <h2 style={{ color: C.cream, fontSize: 18, margin: 0 }}>برنامه غذایی امروز</h2>
        <button onClick={onRegenerate} disabled={loading} style={{ background: C.panelLight, color: loading ? C.muted : C.cream, border: `1px solid ${C.avocadoDark}55`, borderRadius: 10, padding: "6px 12px", fontSize: 12, fontWeight: 700, cursor: loading ? "not-allowed" : "pointer", fontFamily: "inherit" }}>{loading ? "..." : "🔄 بازسازی"}</button>
      </div>
      <div style={{ display: "flex", gap: 8, marginBottom: 10, flexWrap: "wrap" }}>
        {[["🔥", "کالری", targets.calories, ""], ["🥑", "چربی", targets.fatG, "g"], ["🥩", "پروتئین", targets.proteinG, "g"], ["🌿", "کربو", targets.carbsG, "g"]].map(([icon, label, val, unit]) => (
          <div key={label} style={{ background: C.panelLight, borderRadius: 14, padding: "10px 14px", flex: "1 1 70px", textAlign: "center" }}>
            <div style={{ fontSize: 18 }}>{icon}</div>
            <div style={{ color: C.fat, fontSize: 17, fontWeight: 800 }}>{fmt(val, 0)}<span style={{ fontSize: 10, color: C.muted }}>{unit}</span></div>
            <div style={{ color: C.muted, fontSize: 10 }}>{label}</div>
          </div>
        ))}
      </div>
      {plan && <div style={{ textAlign: "center", color: C.muted, fontSize: 11.5, marginBottom: 14 }}>مجموع انتخاب‌شده: <span style={{ color: Math.abs(selectedTotal - targets.calories) < targets.calories * 0.1 ? C.avocado : C.fat, fontWeight: 700 }}>{fmt(selectedTotal, 0)}</span> / {fmt(targets.calories, 0)}</div>}
      {loading && !plan && <p style={{ color: C.muted, textAlign: "center" }}>در حال ساخت برنامه با AI... ⏳</p>}
      {plan && (
        <>
          {plan.meals.map((m, i) => {
            const selectedIdx = selections?.[i] ?? 0;
            return (
              <div key={i} style={{ borderTop: `1px solid ${C.avocadoDark}33`, padding: "12px 0" }}>
                <div style={{ display: "flex", justifyContent: "space-between", color: C.avocado, fontWeight: 700, fontSize: 14, marginBottom: 8 }}>
                  <span>{m.name}</span>
                  <span style={{ color: C.muted, fontWeight: 400, fontSize: 12 }}>{fmt(m.options?.[selectedIdx]?.calories, 0)} کالری</span>
                </div>
                <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
                  {(m.options || []).map((opt, oi) => (
                    <div key={oi} onClick={() => onSelectOption(i, oi)} style={{ background: selectedIdx === oi ? `${C.fat}1A` : C.panelLight, border: `2px solid ${selectedIdx === oi ? C.fat : C.avocadoDark + "33"}`, borderRadius: 12, padding: "10px 12px", cursor: "pointer", display: "flex", alignItems: "flex-start", gap: 10 }}>
                      <div style={{ width: 18, height: 18, borderRadius: "50%", marginTop: 2, flexShrink: 0, border: `2px solid ${selectedIdx === oi ? C.fat : C.avocadoDark + "66"}`, background: selectedIdx === oi ? C.fat : "transparent", display: "flex", alignItems: "center", justifyContent: "center" }}>
                        {selectedIdx === oi && <div style={{ width: 7, height: 7, borderRadius: "50%", background: "#1A1208" }} />}
                      </div>
                      <div style={{ flex: 1 }}>
                        <div style={{ color: selectedIdx === oi ? C.fat : C.muted, fontSize: 10.5, fontWeight: 700, marginBottom: 3 }}>گزینه {toFa(oi + 1)} · {fmt(opt.calories, 0)} کالری</div>
                        <ul style={{ margin: 0, paddingRight: 16, color: C.cream, fontSize: 13, lineHeight: 1.7 }}>
                          {opt.items.map((it, j) => <li key={j}>{it}</li>)}
                        </ul>
                      </div>
                    </div>
                  ))}
                </div>
                <MealPhotoUpload photo={photos?.[i]} onUpload={(d) => onPhotoUpload(i, d)} onRemove={() => onPhotoRemove(i)} />
              </div>
            );
          })}
          {plan.tips?.length > 0 && (
            <div style={{ marginTop: 12, background: C.panelLight, borderRadius: 12, padding: 12 }}>
              <div style={{ color: C.fat, fontWeight: 700, fontSize: 13, marginBottom: 6 }}>💡 نکات</div>
              <ul style={{ margin: 0, paddingRight: 18, color: C.muted, fontSize: 12.5, lineHeight: 1.8 }}>
                {plan.tips.map((t, i) => <li key={i}>{t}</li>)}
              </ul>
            </div>
          )}
        </>
      )}
    </Card>
  );
}

// ─── WEIGHT CHART ─────────────────────────────────────────────────────────────
function WeightChart({ logs, startWeight }) {
  const points = [{ date: null, weight: startWeight }, ...logs];
  if (points.length < 2) return (
    <div style={{ background: C.panelLight, borderRadius: 16, padding: "24px 14px", textAlign: "center", color: C.muted, fontSize: 12.5, marginBottom: 16 }}>
      📊 بعد از ثبت حداقل یک وزن، نمودار پیشرفت نمایش داده می‌شه
    </div>
  );
  const W = 320, H = 140, padX = 12, padY = 18;
  const weights = points.map(p => p.weight);
  let min = Math.min(...weights), max = Math.max(...weights);
  if (min === max) { min -= 1; max += 1; }
  const xStep = (W - padX * 2) / (points.length - 1);
  const yFor = (w) => H - padY - ((w - min) / (max - min)) * (H - padY * 2);
  const xFor = (i) => padX + i * xStep;
  const linePath = points.map((p, i) => `${i === 0 ? "M" : "L"}${xFor(i)},${yFor(p.weight)}`).join(" ");
  const areaPath = `${linePath} L${xFor(points.length - 1)},${H - padY} L${xFor(0)},${H - padY} Z`;
  const first = points[0].weight, lastW = points[points.length - 1].weight;
  const trendDown = lastW <= first;
  return (
    <div style={{ background: C.panelLight, borderRadius: 16, padding: "16px 14px 10px", marginBottom: 16 }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 8 }}>
        <span style={{ color: C.avocado, fontSize: 13, fontWeight: 700 }}>📊 نمودار پیشرفت وزن</span>
        <span style={{ color: trendDown ? C.avocado : C.danger, fontSize: 12, fontWeight: 700 }}>{trendDown ? "▼" : "▲"} {fmt(Math.abs(lastW - first))} کیلوگرم</span>
      </div>
      <svg viewBox={`0 0 ${W} ${H}`} style={{ width: "100%", height: "auto", display: "block" }}>
        <defs><linearGradient id="weightFill" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stopColor={C.fat} stopOpacity="0.35" /><stop offset="100%" stopColor={C.fat} stopOpacity="0" /></linearGradient></defs>
        {[0.25, 0.5, 0.75].map(f => (<line key={f} x1={padX} x2={W - padX} y1={padY + f * (H - padY * 2)} y2={padY + f * (H - padY * 2)} stroke={`${C.avocadoDark}33`} strokeWidth="1" />))}
        <path d={areaPath} fill="url(#weightFill)" stroke="none" />
        <path d={linePath} fill="none" stroke={C.fat} strokeWidth="2.5" strokeLinejoin="round" strokeLinecap="round" />
        {points.map((p, i) => (<circle key={i} cx={xFor(i)} cy={yFor(p.weight)} r={i === points.length - 1 ? 4.5 : 3} fill={i === points.length - 1 ? C.fat : C.bg} stroke={C.fat} strokeWidth="2" />))}
      </svg>
      <div style={{ display: "flex", justifyContent: "space-between", marginTop: 4 }}>
        <span style={{ color: C.muted, fontSize: 10 }}>شروع: {fmt(first)} کیلو</span>
        <span style={{ color: C.muted, fontSize: 10 }}>الان: {fmt(lastW)} کیلو</span>
      </div>
    </div>
  );
}

// ─── WEIGHT LOG ───────────────────────────────────────────────────────────────
function WeightLog({ logs, startWeight, onAdd }) {
  const [val, setVal] = useState("");
  const last = logs[logs.length - 1];
  const lossPct = startWeight && last ? (((startWeight - last.weight) / startWeight) * 100) : 0;
  return (
    <Card>
      <h2 style={{ color: C.cream, fontSize: 18, marginTop: 0 }}>ثبت وزن</h2>
      <WeightChart logs={logs} startWeight={startWeight} />
      <div style={{ display: "flex", gap: 10, marginBottom: 16 }}>
        <input style={{ background: C.panelLight, border: `1px solid ${C.avocadoDark}55`, color: C.cream, borderRadius: 10, padding: "10px 12px", fontSize: 15, outline: "none", fontFamily: "inherit", flex: 1 }}
          type="number" placeholder="وزن جدید (کیلوگرم)" value={val} onChange={e => setVal(e.target.value)} />
        <button onClick={() => { if (!val) return; onAdd(+val); setVal(""); }}
          style={{ background: C.fat, color: "#1A1208", border: "none", borderRadius: 10, padding: "10px 18px", fontSize: 14, fontWeight: 700, cursor: "pointer", fontFamily: "inherit" }}>ثبت</button>
      </div>
      <div style={{ display: "flex", gap: 16, marginBottom: 14 }}>
        {[["وزن شروع", fmt(startWeight), C.cream], ["آخرین", last ? fmt(last.weight) : "—", C.cream], ["پیشرفت", `${fmt(lossPct)}٪`, lossPct >= 0 ? C.avocado : C.danger]].map(([label, val, color]) => (
          <div key={label}><div style={{ color: C.muted, fontSize: 11 }}>{label}</div><div style={{ color, fontWeight: 700 }}>{val}</div></div>
        ))}
      </div>
      {logs.length > 0 && (
        <div style={{ display: "flex", flexDirection: "column", gap: 6, maxHeight: 160, overflowY: "auto" }}>
          {logs.slice().reverse().map((l, i) => (
            <div key={i} style={{ display: "flex", justifyContent: "space-between", fontSize: 12.5, color: C.muted, borderBottom: `1px solid ${C.avocadoDark}22`, padding: "4px 0" }}>
              <span>{new Date(l.date).toLocaleDateString("fa-IR")}</span>
              <span style={{ color: C.cream }}>{fmt(l.weight)} کیلوگرم</span>
            </div>
          ))}
        </div>
      )}
    </Card>
  );
}

// ─── CONSULT CHAT ─────────────────────────────────────────────────────────────
const QUICK_PROMPTS = ["چطور روزه‌داری متناوب بگیرم؟", "چرا وزنم کم نمیشه؟", "کتوفلو چیه؟", "آیا میوه توی کتو مجازه؟"];

function ConsultChat({ phone, profile, targets }) {
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const [loaded, setLoaded] = useState(false);
  const bottomRef = useRef(null);

  useEffect(() => {
    (async () => {
      const saved = await getJSON(`chat:${phone}`, false);
      if (saved) setMessages(saved);
      setLoaded(true);
    })();
  }, [phone]);

  useEffect(() => { bottomRef.current?.scrollIntoView({ behavior: "smooth" }); }, [messages, loading]);

  const send = async (text) => {
    const content = (text ?? input).trim();
    if (!content || loading) return;
    const next = [...messages, { role: "user", content }];
    setMessages(next); setInput(""); setLoading(true);
    await setJSON(`chat:${phone}`, next, false);
    try {
      const reply = await sendConsultMessage(next, profile, targets);
      const withReply = [...next, { role: "assistant", content: reply }];
      setMessages(withReply);
      await setJSON(`chat:${phone}`, withReply, false);
    } catch {
      setMessages([...next, { role: "assistant", content: "⚠️ مشکلی در دریافت پاسخ پیش اومد." }]);
    }
    setLoading(false);
  };

  return (
    <Card style={{ display: "flex", flexDirection: "column", height: 520, padding: 16 }}>
      <h2 style={{ color: C.cream, fontSize: 18, margin: "0 0 12px" }}>💬 مشاوره با دستیار کتوفیت</h2>
      <div style={{ flex: 1, overflowY: "auto", display: "flex", flexDirection: "column", gap: 10, paddingBottom: 8 }}>
        {loaded && messages.length === 0 && <div style={{ color: C.muted, fontSize: 12.5, textAlign: "center", marginTop: 20 }}>هر سوالی درباره کتو، تغذیه یا برنامه‌ت داری بپرس 🥑</div>}
        {messages.map((m, i) => (
          <div key={i} style={{ display: "flex", justifyContent: m.role === "user" ? "flex-end" : "flex-start" }}>
            <div style={{ maxWidth: "82%", background: m.role === "user" ? C.fat : C.panelLight, color: m.role === "user" ? "#1A1208" : C.cream, borderRadius: 14, padding: "9px 13px", fontSize: 13.5, lineHeight: 1.7, whiteSpace: "pre-wrap" }}>{m.content}</div>
          </div>
        ))}
        {loading && <div style={{ display: "flex" }}><div style={{ background: C.panelLight, color: C.muted, borderRadius: 14, padding: "9px 13px", fontSize: 13 }}>در حال نوشتن... ⏳</div></div>}
        <div ref={bottomRef} />
      </div>
      {messages.length === 0 && (
        <div style={{ display: "flex", gap: 6, flexWrap: "wrap", marginBottom: 10 }}>
          {QUICK_PROMPTS.map(q => (
            <button key={q} onClick={() => send(q)} style={{ background: C.panelLight, color: C.avocado, border: `1px solid ${C.avocadoDark}55`, borderRadius: 999, padding: "6px 11px", fontSize: 11.5, cursor: "pointer", fontFamily: "inherit" }}>{q}</button>
          ))}
        </div>
      )}
      <div style={{ display: "flex", gap: 8 }}>
        <input value={input} onChange={e => setInput(e.target.value)} onKeyDown={e => e.key === "Enter" && send()}
          placeholder="سوالت رو بنویس..." disabled={loading}
          style={{ flex: 1, background: C.panelLight, border: `1px solid ${C.avocadoDark}55`, color: C.cream, borderRadius: 12, padding: "11px 14px", fontSize: 14, outline: "none", fontFamily: "inherit" }} />
        <button onClick={() => send()} disabled={loading || !input.trim()} style={{ background: loading || !input.trim() ? "#333" : C.fat, color: loading || !input.trim() ? "#666" : "#1A1208", border: "none", borderRadius: 12, padding: "0 18px", fontSize: 16, fontWeight: 700, cursor: loading || !input.trim() ? "not-allowed" : "pointer", fontFamily: "inherit" }}>➤</button>
      </div>
    </Card>
  );
}

// ─── LEADERBOARD ──────────────────────────────────────────────────────────────
function Leaderboard({ entries, currentUser }) {
  const sorted = entries.slice().sort((a, b) => b.lossPercent - a.lossPercent).slice(0, 20);
  const medals = ["🥇", "🥈", "🥉"];
  return (
    <Card>
      <h2 style={{ color: C.cream, fontSize: 18, marginTop: 0 }}>🏆 رنکینگ این ماه</h2>
      <p style={{ color: C.muted, fontSize: 12, marginTop: -8, marginBottom: 14 }}>برترین‌ها بر اساس بیشترین درصد کاهش وزن</p>
      {sorted.length === 0 && <p style={{ color: C.muted, fontSize: 13 }}>هنوز کسی وزن ثبت نکرده.</p>}
      <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
        {sorted.map((e, i) => (
          <div key={e.username} style={{ display: "flex", justifyContent: "space-between", alignItems: "center", background: e.username === currentUser ? C.panelLight : "transparent", borderRadius: 10, padding: "8px 12px", border: e.username === currentUser ? `1px solid ${C.fat}66` : "1px solid transparent" }}>
            <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
              <span style={{ width: 22, textAlign: "center", color: C.muted }}>{medals[i] || toFa(i + 1)}</span>
              <span style={{ color: C.cream, fontWeight: e.username === currentUser ? 800 : 500 }}>{e.username.slice(0, 4)}***{e.username.slice(-3)}</span>
            </div>
            <span style={{ color: e.lossPercent >= 0 ? C.avocado : C.danger, fontWeight: 700 }}>{fmt(e.lossPercent)}٪</span>
          </div>
        ))}
      </div>
    </Card>
  );
}

// ─── MAIN APP ─────────────────────────────────────────────────────────────────
export default function App() {
  const [user, setUser] = useState(null);
  const [profile, setProfile] = useState(null);
  const [logs, setLogs] = useState([]);
  const [weekLogs, setWeekLogs] = useState([]);
  const [plan, setPlan] = useState(null);
  const [planLoading, setPlanLoading] = useState(false);
  const [savingProfile, setSavingProfile] = useState(false);
  const [leaderboard, setLeaderboard] = useState([]);
  const [tab, setTab] = useState("plan");
  const [startDate, setStartDate] = useState(null);
  const [mealSelections, setMealSelections] = useState({});
  const [mealPhotos, setMealPhotos] = useState({});

  const loadLeaderboard = useCallback(async () => {
    const r = await storageList("leaderboard:", true).catch(() => null);
    if (!r) return;
    const all = await Promise.all(r.keys.map(k => getJSON(k, true)));
    setLeaderboard(all.filter(Boolean));
  }, []);

  const handleLogin = async (phone) => {
    setUser(phone);
    const p = await getJSON(`profile:${phone}`, false);
    const l = (await getJSON(`weights:${phone}`, false)) || [];
    const wl = (await getJSON(`weeklogs:${phone}`, false)) || [];
    const sd = await getJSON(`startdate:${phone}`, false);
    setProfile(p); setLogs(l); setWeekLogs(wl);
    setStartDate(sd || Date.now());
    const ms = (await getJSON(`mealselections:${phone}`, false)) || {};
    const mp = (await getJSON(`mealphotos:${phone}`, false)) || {};
    setMealSelections(ms); setMealPhotos(mp);
    if (p) {
      const existingPlan = await getJSON(`plan:${phone}`, false);
      if (existingPlan) setPlan(existingPlan);
      else {
        setPlanLoading(true);
        try { const np = await generatePlan(p, calcTargets(p)); setPlan(np); setJSON(`plan:${phone}`, np, false); }
        catch (e) { console.error(e); }
        setPlanLoading(false);
      }
    }
    await loadLeaderboard();
  };

  const handleSaveProfile = async (form) => {
    setSavingProfile(true);
    const sd = await getJSON(`startdate:${user}`, false) || Date.now();
    await setJSON(`profile:${user}`, form, false);
    await setJSON(`startdate:${user}`, sd, false);
    setProfile(form); setStartDate(sd);
    setPlanLoading(true);
    try {
      const np = await generatePlan(form, calcTargets(form));
      setPlan(np); await setJSON(`plan:${user}`, np, false);
      setMealSelections({}); setMealPhotos({});
      await setJSON(`mealselections:${user}`, {}, false);
      await setJSON(`mealphotos:${user}`, {}, false);
    } catch (e) { console.error(e); }
    setPlanLoading(false); setSavingProfile(false);
    const existing = await getJSON(`leaderboard:${user}`, true);
    if (!existing) {
      await setJSON(`leaderboard:${user}`, { username: user, startWeight: form.weight, currentWeight: form.weight, lossPercent: 0, lastUpdate: Date.now() }, true);
      await loadLeaderboard();
    }
    setTab("plan");
  };

  const handleAddWeight = async (weight) => {
    const nl = [...logs, { date: Date.now(), weight }];
    setLogs(nl); await setJSON(`weights:${user}`, nl, false);
    const lb = (await getJSON(`leaderboard:${user}`, true)) || { username: user, startWeight: profile.weight, currentWeight: weight, lossPercent: 0 };
    const sw = lb.startWeight || profile.weight;
    const lp = ((sw - weight) / sw) * 100;
    await setJSON(`leaderboard:${user}`, { username: user, startWeight: sw, currentWeight: weight, lossPercent: lp, lastUpdate: Date.now() }, true);
    await loadLeaderboard();
  };

  const handleSelectOption = async (mealIdx, optIdx) => {
    const next = { ...mealSelections, [mealIdx]: optIdx };
    setMealSelections(next);
    await setJSON(`mealselections:${user}`, next, false);
  };

  const handlePhotoUpload = async (mealIdx, dataUrl) => {
    const next = { ...mealPhotos, [mealIdx]: dataUrl };
    setMealPhotos(next);
    await setJSON(`mealphotos:${user}`, next, false);
  };

  const handlePhotoRemove = async (mealIdx) => {
    const next = { ...mealPhotos };
    delete next[mealIdx];
    setMealPhotos(next);
    await setJSON(`mealphotos:${user}`, next, false);
  };

  const handleLogout = () => {
    localStorage.removeItem("ketofit_token");
    localStorage.removeItem("ketofit_phone");
    setAuthToken(null);
    setUser(null); setProfile(null); setLogs([]); setPlan(null);
  };

  useEffect(() => {
    document.body.style.background = C.bg;
    document.body.style.margin = "0";
  }, []);

  const wrap = { fontFamily: "'Vazirmatn','IRANSans',Tahoma,sans-serif", direction: "rtl", minHeight: "100vh", background: C.bg, color: C.cream };

  if (!user) return <div style={wrap}><LoginScreen onLogin={handleLogin} /></div>;
  if (!profile) return <div style={wrap}><Onboarding onSave={handleSaveProfile} saving={savingProfile} /></div>;

  const targets = calcTargets(profile);
  const TABS = [
    ["plan", "🍽️", "برنامه"],
    ["consult", "💬", "مشاوره"],
    ["week", "📅", "هفتگی"],
    ["weight", "⚖️", "وزن"],
    ["invite", "🎁", "دعوت"],
    ["leaderboard", "🏆", "رنکینگ"],
    ["profile", "👤", "پروفایل"],
  ];

  return (
    <div style={wrap}>
      <div style={{ maxWidth: 720, margin: "0 auto", padding: "20px 14px 80px" }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 18 }}>
          <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
            <span style={{ fontSize: 24 }}>🥑</span>
            <span style={{ fontWeight: 800, fontSize: 17 }}>کتوفیت</span>
          </div>
          <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
            <span style={{ color: C.muted, fontSize: 12 }}>{user.slice(0, 4)}***{user.slice(-3)}</span>
            <button onClick={handleLogout} style={{ background: C.panelLight, color: C.cream, border: `1px solid ${C.avocadoDark}55`, borderRadius: 10, padding: "5px 11px", fontSize: 12, fontWeight: 700, cursor: "pointer", fontFamily: "inherit" }}>خروج</button>
          </div>
        </div>
        <div style={{ display: "flex", gap: 6, marginBottom: 18, overflowX: "auto", paddingBottom: 4 }}>
          {TABS.map(([key, icon, label]) => (
            <button key={key} onClick={() => setTab(key)} style={{ background: tab === key ? C.fat : C.panel, color: tab === key ? "#1A1208" : C.muted, border: "none", borderRadius: 999, padding: "7px 13px", fontSize: 12, fontWeight: 700, cursor: "pointer", fontFamily: "inherit", whiteSpace: "nowrap", flexShrink: 0 }}>{icon} {label}</button>
          ))}
        </div>
        {tab === "plan" && <PlanCard plan={plan} targets={targets} onRegenerate={async () => {
          setPlanLoading(true);
          try { const np = await generatePlan(profile, targets); setPlan(np); await setJSON(`plan:${user}`, np, false); }
          catch (e) { console.error(e); } setPlanLoading(false);
        }} loading={planLoading} selections={mealSelections} onSelectOption={handleSelectOption} photos={mealPhotos} onPhotoUpload={handlePhotoUpload} onPhotoRemove={handlePhotoRemove} />}
        {tab === "consult" && <ConsultChat phone={user} profile={profile} targets={targets} />}
        {tab === "week" && <WeeklyTracker startDate={startDate} logs={weekLogs} targets={targets} />}
        {tab === "weight" && <WeightLog logs={logs} startWeight={profile.weight} onAdd={handleAddWeight} />}
        {tab === "invite" && <InviteScreen userPhone={user} />}
        {tab === "leaderboard" && <Leaderboard entries={leaderboard} currentUser={user} />}
        {tab === "profile" && <Onboarding initial={profile} onSave={handleSaveProfile} saving={savingProfile} />}
      </div>
    </div>
  );
}
